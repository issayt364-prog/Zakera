package com.thakera.questionreview;

import org.json.JSONException;
import org.json.JSONObject;

public class Folder {
    public String id;
    public String name;
    public String parentId;

    public Folder(String id, String name) {
        this(id, name, null);
    }

    public Folder(String id, String name, String parentId) {
        this.id = id;
        this.name = name;
        this.parentId = parentId;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject object = new JSONObject();
        object.put("id", id);
        object.put("name", name);
        object.put("parentId", parentId == null ? JSONObject.NULL : parentId);
        return object;
    }

    public static Folder fromJson(JSONObject object) {
        String parentId = object.optString("parentId", "");
        if (parentId.isEmpty() || "null".equals(parentId)) parentId = null;
        return new Folder(
                object.optString("id", Utils.newId()),
                object.optString("name", "مجلد بدون اسم"),
                parentId
        );
    }
}