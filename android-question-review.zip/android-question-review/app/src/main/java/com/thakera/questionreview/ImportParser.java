package com.thakera.questionreview;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ImportParser {
    public static class ImportedQuestion {
        public final String prompt;
        public final String answer;
        public final String type;
        public final ArrayList<String> options;
        public final int correctOptionIndex;

        public ImportedQuestion(String prompt, String answer) {
            this(prompt, answer, Question.TYPE_OPEN, new ArrayList<>(), -1);
        }

        public ImportedQuestion(String prompt, String answer, String type,
                                ArrayList<String> options, int correctOptionIndex) {
            this.prompt = prompt;
            this.answer = answer;
            this.type = type;
            this.options = options;
            this.correctOptionIndex = correctOptionIndex;
        }
    }

    private ImportParser() {
    }

    public static ArrayList<ImportedQuestion> parse(String raw) {
        ArrayList<ImportedQuestion> result = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) return result;
        String text = raw.replace("\r\n", "\n").trim();

        if (tryParseJson(text, result)) return result;

        Pattern questionPattern = Pattern.compile(
                "^(?:سؤال|س|question)\\s*[:：-]\\s*(.*)$",
                Pattern.CASE_INSENSITIVE
        );
        Pattern answerPattern = Pattern.compile(
                "^(?:جواب|ج|إجابة|الجواب|الإجابة|answer)\\s*[:：-]\\s*(.*)$",
                Pattern.CASE_INSENSITIVE
        );
        String currentPrompt = null;
        StringBuilder currentAnswer = new StringBuilder();
        boolean sawMarker = false;
        for (String rawLine : text.split("\n")) {
            String line = rawLine.trim();
            Matcher questionMatcher = questionPattern.matcher(line);
            Matcher answerMatcher = answerPattern.matcher(line);
            if (questionMatcher.matches()) {
                sawMarker = true;
                addIfComplete(result, currentPrompt, currentAnswer.toString());
                currentPrompt = questionMatcher.group(1).trim();
                currentAnswer = new StringBuilder();
            } else if (answerMatcher.matches() && currentPrompt != null) {
                sawMarker = true;
                appendLine(currentAnswer, answerMatcher.group(1).trim());
            } else if (currentPrompt != null) {
                appendLine(currentAnswer, rawLine.trim());
            }
        }
        addIfComplete(result, currentPrompt, currentAnswer.toString());
        if (sawMarker) return result;

        for (String block : text.split("\\n\\s*---+\\s*\\n|\\n{2,}")) {
            String[] lines = block.trim().split("\\n");
            String prompt = lines.length > 0 ? lines[0].trim() : "";
            StringBuilder answer = new StringBuilder();
            for (int index = 1; index < lines.length; index++) {
                appendLine(answer, lines[index].trim());
            }
            addIfComplete(result, prompt, answer.toString());
        }
        return result;
    }

    private static boolean tryParseJson(String text, ArrayList<ImportedQuestion> result) {
        try {
            Object parsed = new org.json.JSONTokener(text).nextValue();
            JSONArray list;
            if (parsed instanceof JSONArray) {
                list = (JSONArray) parsed;
            } else if (parsed instanceof JSONObject) {
                list = ((JSONObject) parsed).optJSONArray("questions");
                if (list == null) return false;
            } else {
                return false;
            }
            for (int index = 0; index < list.length(); index++) {
                JSONObject item = list.optJSONObject(index);
                if (item == null) continue;
                String prompt = firstValue(item, "prompt", "question", "سؤال");
                String answer = firstValue(item, "answer", "response", "جواب", "إجابة", "الجواب", "الإجابة");
                String type = item.optString("type", Question.TYPE_OPEN);
                JSONArray optionArray = item.optJSONArray("options");
                int correctOptionIndex = item.optInt("correctOptionIndex", -1);
                boolean isMcq = Question.TYPE_MCQ.equals(type)
                        || (optionArray != null && optionArray.length() >= 2 && correctOptionIndex >= 0);
                if (!isMcq) {
                    addIfComplete(result, prompt, answer);
                    continue;
                }

                ArrayList<String> options = new ArrayList<>();
                if (optionArray != null) {
                    for (int optionIndex = 0; optionIndex < optionArray.length(); optionIndex++) {
                        options.add(optionArray.optString(optionIndex, "").trim());
                    }
                }
                boolean validOptions = options.size() >= 2 && options.size() <= 4
                        && correctOptionIndex >= 0 && correctOptionIndex < options.size();
                for (String option : options) {
                    if (option.isEmpty()) validOptions = false;
                }
                if (prompt != null && !prompt.trim().isEmpty() && validOptions) {
                    result.add(new ImportedQuestion(
                            prompt.trim(), answer, Question.TYPE_MCQ, options, correctOptionIndex
                    ));
                }
            }
            return true;
        } catch (JSONException ignored) {
            return false;
        }
    }

    private static String firstValue(JSONObject object, String... keys) {
        for (String key : keys) {
            String value = object.optString(key, "").trim();
            if (!value.isEmpty()) return value;
        }
        return "";
    }

    private static void appendLine(StringBuilder builder, String value) {
        if (value == null || value.isEmpty()) return;
        if (builder.length() > 0) builder.append('\n');
        builder.append(value);
    }

    private static void addIfComplete(ArrayList<ImportedQuestion> result, String prompt, String answer) {
        if (prompt != null && !prompt.trim().isEmpty() && answer != null && !answer.trim().isEmpty()) {
            result.add(new ImportedQuestion(prompt.trim(), answer.trim()));
        }
    }
}