package com.thakera.questionreview;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends android.app.Activity {
    private static final int REQUEST_IMPORT_FILE = 100;
    private static final int REQUEST_IMAGE_FILE = 101;
    private static final int REQUEST_EXPORT_FILE = 102;
    private static final int REQUEST_EXPORT_ICS = 103;
    private static final int REQUEST_POST_NOTIFICATIONS = 104;

    private QuestionStorage storage;
    private final ArrayList<Question> questions = new ArrayList<>();
    private final ArrayList<Folder> folders = new ArrayList<>();
    private final Map<String, Integer> folderDepths = new HashMap<>();
    private final Calendar displayedMonth = Calendar.getInstance();
    private String selectedFolderId;
    private String selectedCalendarDate = Utils.today();
    private boolean updatingFolderSpinner;
    private EditText activeImportInput;
    private Dialog activeQuestionDialog;
    private ImageView activeImagePreview;
    private Button activeRemoveImageButton;
    private String activeImagePath;
    private Uri activePendingImageUri;
    private String pendingExport;
    private String pendingIcs;

    private LinearLayout dueList;
    private LinearLayout libraryList;
    private LinearLayout folderList;
    private LinearLayout calendarDayList;
    private TextView dueCount;
    private TextView totalCount;
    private TextView emptyState;
    private TextView calendarMonthLabel;
    private TextView calendarSelectedDateLabel;
    private Button notificationsButton;
    private Button startMcqQuizButton;
    private GridLayout calendarGrid;
    private Spinner folderFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setContentView(R.layout.activity_main);

        storage = new QuestionStorage(this);
        questions.addAll(storage.loadQuestions());
        folders.addAll(storage.loadFolders());
        displayedMonth.set(Calendar.DAY_OF_MONTH, 1);
        String notificationDate = getIntent().getStringExtra("open_calendar_date");
        if (Utils.isValidDate(notificationDate == null ? "" : notificationDate)) {
            selectedCalendarDate = notificationDate;
            displayedMonth.setTime(parseDate(notificationDate));
            displayedMonth.set(Calendar.DAY_OF_MONTH, 1);
        }

        dueList = findViewById(R.id.due_list);
        libraryList = findViewById(R.id.library_list);
        folderList = findViewById(R.id.folder_list);
        calendarDayList = findViewById(R.id.calendar_day_list);
        dueCount = findViewById(R.id.due_count);
        totalCount = findViewById(R.id.total_count);
        emptyState = findViewById(R.id.empty_state);
        calendarGrid = findViewById(R.id.calendar_grid);
        calendarMonthLabel = findViewById(R.id.calendar_month);
        calendarSelectedDateLabel = findViewById(R.id.calendar_selected_date);
        notificationsButton = findViewById(R.id.notifications_button);
        startMcqQuizButton = findViewById(R.id.start_mcq_quiz_button);
        folderFilter = findViewById(R.id.folder_filter);

        findViewById(R.id.add_question_button).setOnClickListener(view -> showQuestionDialog(null));
        findViewById(R.id.import_button).setOnClickListener(view -> showImportDialog());
        findViewById(R.id.add_folder_button).setOnClickListener(view -> showFolderDialog());
        findViewById(R.id.export_button).setOnClickListener(view -> exportJson());
        findViewById(R.id.calendar_previous).setOnClickListener(view -> moveCalendarMonth(-1));
        findViewById(R.id.calendar_next).setOnClickListener(view -> moveCalendarMonth(1));
        findViewById(R.id.calendar_today).setOnClickListener(view -> showCalendarToday());
        notificationsButton.setOnClickListener(view -> enableNotifications());
        startMcqQuizButton.setOnClickListener(view -> startAllMcqQuiz());

        folderFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (updatingFolderSpinner) return;
                ArrayList<Folder> ordered = orderedFolders();
                String newSelection = position == 0 || position > ordered.size()
                        ? null
                        : ordered.get(position - 1).id;
                if (selectedFolderId == null ? newSelection == null : selectedFolderId.equals(newSelection)) {
                    return;
                }
                selectedFolderId = newSelection;
                render();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });

        ReminderScheduler.rescheduleAll(this, questions, true);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (storage != null) {
            ReminderScheduler.rescheduleAll(this, questions);
            updateNotificationsButton();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String date = intent.getStringExtra("open_calendar_date");
        if (Utils.isValidDate(date == null ? "" : date)) {
            selectedCalendarDate = date;
            displayedMonth.setTime(parseDate(date));
            displayedMonth.set(Calendar.DAY_OF_MONTH, 1);
            if (calendarGrid != null) renderCalendar();
        }
    }

    private void render() {
        renderFolderFilter();
        renderFolderSummary();
        renderCalendar();

        ArrayList<Question> due = new ArrayList<>();
        for (Question question : questions) {
            if (Utils.isDue(question.nextReviewDate)) due.add(question);
        }
        Collections.sort(due, Comparator.comparing(question -> question.nextReviewDate));
        dueList.removeAllViews();
        for (Question question : due) addQuestionCard(dueList, question);
        if (due.isEmpty()) {
            addMessage(dueList, "لا توجد مراجعات مستحقة الآن. أضف سؤالًا جديدًا أو استكشف مكتبتك.");
        }

        ArrayList<Question> visible = new ArrayList<>();
        for (Question question : questions) {
            if (selectedFolderId == null || isFolderWithinTree(question.folderId, selectedFolderId)) {
                visible.add(question);
            }
        }
        libraryList.removeAllViews();
        for (Question question : visible) addQuestionCard(libraryList, question);
        emptyState.setVisibility(visible.isEmpty() ? View.VISIBLE : View.GONE);
        dueCount.setText(toArabicNumber(due.size()) + "\nمستحقة");
        totalCount.setText(toArabicNumber(questions.size()) + "\nبطاقة");
        updateMcqQuizButton();
    }

    private void updateMcqQuizButton() {
        int validCount = 0;
        for (Question question : questions) {
            if (question.hasValidMcq()) validCount++;
        }
        startMcqQuizButton.setText("ابدأ اختبار MCQ · " + toArabicNumber(validCount) + " سؤال");
        startMcqQuizButton.setEnabled(validCount > 0);
    }

    private void startAllMcqQuiz() {
        ArrayList<Question> quizQuestions = new ArrayList<>();
        for (Question question : questions) {
            if (question.hasValidMcq()) quizQuestions.add(question);
        }
        if (quizQuestions.isEmpty()) {
            showToast("أضف سؤال اختيار من متعدد صالحًا أولًا");
            return;
        }
        Collections.shuffle(quizQuestions);
        startQuizSession(quizQuestions);
    }

    private void startSingleMcqQuiz(Question question) {
        if (!question.hasValidMcq()) {
            showToast("أكمل خيارات هذا السؤال وإجابته الصحيحة أولًا");
            return;
        }
        ArrayList<Question> quizQuestions = new ArrayList<>();
        quizQuestions.add(question);
        startQuizSession(quizQuestions);
    }

    private void startQuizSession(ArrayList<Question> quizQuestions) {
        View quizView = LayoutInflater.from(this).inflate(R.layout.dialog_quiz, null);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("اختبار اختيار من متعدد")
                .setView(quizView)
                .setNegativeButton("إنهاء الاختبار", null)
                .create();
        dialog.show();
        showQuizQuestion(quizQuestions, 0, 0, dialog, quizView);
    }

    private void showQuizQuestion(
            ArrayList<Question> quizQuestions,
            int questionIndex,
            int score,
            AlertDialog dialog,
            View quizView
    ) {
        Question question = quizQuestions.get(questionIndex);
        TextView progress = quizView.findViewById(R.id.quiz_progress);
        TextView prompt = quizView.findViewById(R.id.quiz_prompt);
        TextView feedback = quizView.findViewById(R.id.quiz_feedback);
        RadioGroup choicesGroup = quizView.findViewById(R.id.quiz_options);
        Button checkButton = quizView.findViewById(R.id.quiz_check_button);
        Button nextButton = quizView.findViewById(R.id.quiz_next_button);
        final int[] scoreAfterAnswer = {score};

        progress.setText("السؤال " + toArabicNumber(questionIndex + 1) + " من "
                + toArabicNumber(quizQuestions.size()) + "  ·  النقاط " + toArabicNumber(score));
        prompt.setText(question.prompt);
        feedback.setVisibility(View.GONE);
        choicesGroup.clearCheck();
        choicesGroup.removeAllViews();
        checkButton.setVisibility(View.VISIBLE);
        nextButton.setVisibility(View.GONE);
        nextButton.setText(questionIndex == quizQuestions.size() - 1 ? "عرض النتيجة" : "السؤال التالي");

        for (int index = 0; index < question.options.size(); index++) {
            RadioButton choice = new RadioButton(this);
            choice.setId(View.generateViewId());
            choice.setTag(index);
            choice.setText(question.options.get(index));
            choice.setTextSize(16);
            choice.setTextColor(getColor(R.color.text_primary));
            choice.setPadding(dp(8), dp(10), dp(8), dp(10));
            choice.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            choicesGroup.addView(choice, new RadioGroup.LayoutParams(
                    RadioGroup.LayoutParams.MATCH_PARENT,
                    RadioGroup.LayoutParams.WRAP_CONTENT
            ));
        }

        checkButton.setOnClickListener(view -> {
            int checkedId = choicesGroup.getCheckedRadioButtonId();
            if (checkedId == View.NO_ID) {
                showToast("اختر إجابة قبل المتابعة");
                return;
            }
            RadioButton selectedChoice = quizView.findViewById(checkedId);
            int selectedIndex = (Integer) selectedChoice.getTag();
            boolean isCorrect = selectedIndex == question.correctOptionIndex;
            final int updatedScore = score + (isCorrect ? 1 : 0);
            scoreAfterAnswer[0] = updatedScore;

            for (int index = 0; index < choicesGroup.getChildCount(); index++) {
                RadioButton choice = (RadioButton) choicesGroup.getChildAt(index);
                choice.setEnabled(false);
                if (index == question.correctOptionIndex) {
                    choice.setTextColor(Color.rgb(35, 128, 76));
                } else if (index == selectedIndex) {
                    choice.setTextColor(getColor(R.color.danger));
                }
            }

            String feedbackText = isCorrect
                    ? "إجابة صحيحة"
                    : "إجابة غير صحيحة.\nالإجابة الصحيحة: "
                    + question.options.get(question.correctOptionIndex);
            if (question.answer != null && !question.answer.trim().isEmpty()) {
                feedbackText += "\n\nالشرح: " + question.answer.trim();
            }
            feedback.setText(feedbackText);
            feedback.setTextColor(isCorrect ? Color.rgb(35, 128, 76) : getColor(R.color.danger));
            feedback.setVisibility(View.VISIBLE);
            checkButton.setVisibility(View.GONE);
            nextButton.setVisibility(View.VISIBLE);
            recordQuizReview(question);
            progress.setText("السؤال " + toArabicNumber(questionIndex + 1) + " من "
                    + toArabicNumber(quizQuestions.size()) + "  ·  النقاط " + toArabicNumber(updatedScore));
        });

        nextButton.setOnClickListener(view -> {
            if (questionIndex + 1 < quizQuestions.size()) {
                showQuizQuestion(quizQuestions, questionIndex + 1, scoreAfterAnswer[0], dialog, quizView);
            } else {
                dialog.dismiss();
                showQuizResult(scoreAfterAnswer[0], quizQuestions.size());
            }
        });
    }

    private void showQuizResult(int score, int total) {
        int percent = total == 0 ? 0 : Math.round(score * 100f / total);
        new AlertDialog.Builder(this)
                .setTitle("انتهى الاختبار")
                .setMessage("نتيجتك: " + toArabicNumber(score) + " من " + toArabicNumber(total)
                        + " (" + toArabicNumber(percent) + "%)")
                .setPositiveButton("حسنًا", null)
                .show();
    }

    private void recordQuizReview(Question question) {
        advanceReviewSchedule(question);
    }

    private void advanceReviewSchedule(Question question) {
        String today = Utils.today();
        question.nextReviewDate = Utils.addReviewInterval(today, question.reviewStage);
        question.reviewStage = Math.min(3, question.reviewStage + 1);
        question.reviewCount++;
        question.lastReviewedAt = today;
        saveQuestionsAndSchedule();
        render();
    }

    private void renderCalendar() {
        calendarGrid.removeAllViews();
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM yyyy", new Locale("ar"));
        calendarMonthLabel.setText(monthFormat.format(displayedMonth.getTime()));

        String[] weekdays = {"سبت", "أحد", "اثن", "ثلا", "أرب", "خمي", "جمع"};
        for (int column = 0; column < weekdays.length; column++) {
            TextView weekday = new TextView(this);
            weekday.setText(weekdays[column]);
            weekday.setTextColor(getColor(R.color.text_muted));
            weekday.setTextSize(10);
            weekday.setGravity(android.view.Gravity.CENTER);
            weekday.setPadding(0, dp(5), 0, dp(5));
            GridLayout.LayoutParams params = new GridLayout.LayoutParams(
                    GridLayout.spec(0),
                    GridLayout.spec(column, 1, 1f)
            );
            params.width = 0;
            params.height = dp(34);
            calendarGrid.addView(weekday, params);
        }

        Calendar month = (Calendar) displayedMonth.clone();
        month.set(Calendar.DAY_OF_MONTH, 1);
        int firstOffset = month.get(Calendar.DAY_OF_WEEK) % 7;
        int daysInMonth = month.getActualMaximum(Calendar.DAY_OF_MONTH);
        int cellCount = ((firstOffset + daysInMonth + 6) / 7) * 7;
        String today = Utils.today();
        int row = 1;
        for (int cell = 0; cell < cellCount; cell++) {
            int day = cell - firstOffset + 1;
            TextView dayCell = new TextView(this);
            GridLayout.LayoutParams params = new GridLayout.LayoutParams(
                    GridLayout.spec(row),
                    GridLayout.spec(cell % 7, 1, 1f)
            );
            params.width = 0;
            params.height = dp(58);
            params.setMargins(dp(2), dp(2), dp(2), dp(2));
            if (day < 1 || day > daysInMonth) {
                calendarGrid.addView(dayCell, params);
                if (cell % 7 == 6) row++;
                continue;
            }

            month.set(Calendar.DAY_OF_MONTH, day);
            String isoDate = Utils.todayDate(month);
            int count = questionCountForDate(isoDate);
            dayCell.setText(count == 0
                    ? toArabicNumber(day)
                    : toArabicNumber(day) + "\n• " + toArabicNumber(count));
            dayCell.setTextSize(count == 0 ? 14 : 12);
            dayCell.setGravity(android.view.Gravity.CENTER);
            dayCell.setLineSpacing(0, 0.9f);
            dayCell.setTextColor(isoDate.equals(selectedCalendarDate)
                    ? Color.WHITE
                    : count > 0 ? getColor(R.color.primary) : getColor(R.color.text_muted));
            dayCell.setBackground(calendarCellBackground(isoDate.equals(selectedCalendarDate), isoDate.equals(today)));
            dayCell.setOnClickListener(view -> {
                selectedCalendarDate = isoDate;
                renderCalendar();
            });
            calendarGrid.addView(dayCell, params);
            if (cell % 7 == 6) row++;
        }
        renderCalendarDayList();
    }

    private void renderCalendarDayList() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE، d MMMM yyyy", new Locale("ar"));
        calendarSelectedDateLabel.setText("مراجعات " + dateFormat.format(parseDate(selectedCalendarDate)));
        calendarDayList.removeAllViews();
        int count = 0;
        for (Question question : questions) {
            if (selectedCalendarDate.equals(question.nextReviewDate)) {
                addQuestionCard(calendarDayList, question);
                count++;
            }
        }
        if (count == 0) addMessage(calendarDayList, "لا توجد مراجعات مجدولة في هذا اليوم.");
    }

    private int questionCountForDate(String date) {
        int count = 0;
        for (Question question : questions) {
            if (date.equals(question.nextReviewDate)) count++;
        }
        return count;
    }

    private GradientDrawable calendarCellBackground(boolean selected, boolean today) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setCornerRadius(dp(12));
        if (selected) {
            drawable.setColor(getColor(R.color.primary));
        } else {
            drawable.setColor(Color.WHITE);
            if (today) drawable.setStroke(dp(2), getColor(R.color.accent));
            else drawable.setStroke(dp(1), getColor(R.color.border));
        }
        return drawable;
    }

    private void moveCalendarMonth(int amount) {
        displayedMonth.add(Calendar.MONTH, amount);
        displayedMonth.set(Calendar.DAY_OF_MONTH, 1);
        selectedCalendarDate = Utils.todayDate(displayedMonth);
        renderCalendar();
    }

    private void showCalendarToday() {
        displayedMonth.setTime(parseDate(Utils.today()));
        displayedMonth.set(Calendar.DAY_OF_MONTH, 1);
        selectedCalendarDate = Utils.today();
        renderCalendar();
    }

    private void enableNotifications() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            SharedPreferences preferences = getSharedPreferences("question_review_reminders", MODE_PRIVATE);
            boolean askedBefore = preferences.getBoolean("notification_permission_requested", false);
            if (askedBefore && !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                openNotificationSettings();
                return;
            }
            preferences.edit().putBoolean("notification_permission_requested", true).apply();
            requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    REQUEST_POST_NOTIFICATIONS
            );
            return;
        }

        if (!notificationsAllowedBySystem()) {
            openNotificationSettings();
            return;
        }
        ReminderScheduler.rescheduleAll(this, questions);
        updateNotificationsButton();
        showToast("ستصلك التذكيرات يوميًا عند الساعة ٩ صباحًا");
    }

    private boolean notificationsAllowedBySystem() {
        NotificationManager manager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 24 && !manager.areNotificationsEnabled()) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = manager.getNotificationChannel("review_reminders");
            return channel == null || channel.getImportance() != NotificationManager.IMPORTANCE_NONE;
        }
        return true;
    }

    private void updateNotificationsButton() {
        if (notificationsButton == null) return;
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            SharedPreferences preferences = getSharedPreferences("question_review_reminders", MODE_PRIVATE);
            boolean askedBefore = preferences.getBoolean("notification_permission_requested", false);
            boolean canAskAgain = !askedBefore
                    || shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS);
            notificationsButton.setText(canAskAgain
                    ? "تفعيل تذكيرات المراجعة"
                    : "الإشعارات ممنوعة — افتح الإعدادات");
            return;
        }
        if (!notificationsAllowedBySystem()) {
            notificationsButton.setText("السماح بالإشعارات من إعدادات النظام");
        } else {
            notificationsButton.setText("التذكيرات مفعلة · يوميًا الساعة ٩ صباحًا");
        }
    }

    private void openNotificationSettings() {
        Intent intent;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        } else {
            intent = new Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())
            );
        }
        try {
            startActivity(intent);
        } catch (Exception ignored) {
            Intent fallback = new Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())
            );
            startActivity(fallback);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_POST_NOTIFICATIONS) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            ReminderScheduler.rescheduleAll(this, questions);
            showToast("تم تفعيل تذكيرات المراجعة");
        } else {
            showToast("لن تظهر التذكيرات حتى تسمح بالإشعارات");
        }
        updateNotificationsButton();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private java.util.Date parseDate(String value) {
        try {
            return new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(value);
        } catch (Exception ignored) {
            return Calendar.getInstance().getTime();
        }
    }

    private void renderFolderFilter() {
        ArrayList<Folder> ordered = orderedFolders();
        ArrayList<String> labels = new ArrayList<>();
        labels.add("كل المجلدات");
        for (Folder folder : ordered) labels.add(folderDisplayLabel(folder));
        updatingFolderSpinner = true;
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        folderFilter.setAdapter(adapter);
        int selectedIndex = 0;
        if (selectedFolderId != null) {
            for (int index = 0; index < ordered.size(); index++) {
                if (selectedFolderId.equals(ordered.get(index).id)) {
                    selectedIndex = index + 1;
                    break;
                }
            }
        }
        folderFilter.setSelection(selectedIndex);
        updatingFolderSpinner = false;
    }

    private void renderFolderSummary() {
        folderList.removeAllViews();
        if (folders.isEmpty()) return;
        ArrayList<Folder> ordered = orderedFolders();
        for (Folder folder : ordered) {
            int count = 0;
            Set<String> subtreeIds = new HashSet<>();
            collectFolderSubtree(folder.id, subtreeIds);
            for (Question question : questions) {
                if (subtreeIds.contains(question.folderId)) count++;
            }
            TextView summary = new TextView(this);
            summary.setText("📁  " + folderDisplayLabel(folder) + "  ·  " + toArabicNumber(count) + " بطاقة");
            summary.setTextColor(getColor(R.color.primary));
            summary.setTextSize(13);
            summary.setMaxLines(1);
            summary.setEllipsize(TextUtils.TruncateAt.END);
            summary.setGravity(android.view.Gravity.CENTER_VERTICAL);
            summary.setPadding(dp(8), dp(8), dp(4), dp(8));
            summary.setLayoutParams(new LinearLayout.LayoutParams(0, dp(46), 1f));
            summary.setOnClickListener(view -> {
                selectedFolderId = folder.id;
                render();
            });

            Button addChild = new Button(this);
            addChild.setText("＋ فرعي");
            addChild.setTextSize(11);
            addChild.setTextColor(getColor(R.color.primary));
            addChild.setBackgroundResource(R.drawable.bg_secondary_button);
            addChild.setMinHeight(dp(40));
            addChild.setPadding(dp(6), 0, dp(6), 0);
            addChild.setContentDescription("إضافة مجلد داخل " + folder.name);
            addChild.setOnClickListener(view -> showFolderDialog(folder.id));

            Button delete = new Button(this);
            delete.setText("حذف");
            delete.setTextSize(11);
            delete.setTextColor(getColor(R.color.danger));
            delete.setBackgroundResource(R.drawable.bg_secondary_button);
            delete.setMinHeight(dp(40));
            delete.setPadding(dp(6), 0, dp(6), 0);
            delete.setContentDescription("حذف " + folder.name + " ومحتوياته");
            delete.setOnClickListener(view -> confirmDeleteFolder(folder));

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setBackgroundResource(R.drawable.bg_card);
            row.setPadding(dp(6), dp(2), dp(6), dp(2));
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            rowParams.setMargins(0, 0, 0, dp(6));
            row.addView(summary);
            row.addView(addChild, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dp(40)
            ));
            LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dp(40)
            );
            deleteParams.setMargins(dp(5), 0, 0, 0);
            row.addView(delete, deleteParams);
            folderList.addView(row, rowParams);
        }
    }

    private ArrayList<Folder> orderedFolders() {
        ArrayList<Folder> ordered = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        folderDepths.clear();
        appendChildFolders(null, 0, ordered, visited);

        // Keep legacy or malformed orphaned folders visible rather than losing access to them.
        for (Folder folder : folders) {
            if (visited.add(folder.id)) {
                ordered.add(folder);
                folderDepths.put(folder.id, 0);
                appendChildFolders(folder.id, 1, ordered, visited);
            }
        }
        return ordered;
    }

    private void appendChildFolders(String parentId, int depth, ArrayList<Folder> ordered, Set<String> visited) {
        for (Folder folder : folders) {
            boolean belongsHere = parentId == null
                    ? folder.parentId == null
                    : parentId.equals(folder.parentId);
            if (belongsHere && visited.add(folder.id)) {
                ordered.add(folder);
                folderDepths.put(folder.id, depth);
                appendChildFolders(folder.id, depth + 1, ordered, visited);
            }
        }
    }

    private String folderDisplayLabel(Folder folder) {
        int depth = folderDepths.containsKey(folder.id) ? folderDepths.get(folder.id) : 0;
        StringBuilder prefix = new StringBuilder();
        for (int index = 0; index < depth; index++) prefix.append("　　");
        if (depth > 0) prefix.append("↳ ");
        return prefix + folder.name;
    }

    private boolean isFolderWithinTree(String folderId, String selectedId) {
        if (folderId == null || selectedId == null) return false;
        String currentId = folderId;
        Set<String> visited = new HashSet<>();
        while (currentId != null && visited.add(currentId)) {
            if (selectedId.equals(currentId)) return true;
            Folder current = findFolder(currentId);
            currentId = current == null ? null : current.parentId;
        }
        return false;
    }

    private void addQuestionCard(LinearLayout parent, Question question) {
        View card = LayoutInflater.from(this).inflate(R.layout.item_question, parent, false);
        TextView prompt = card.findViewById(R.id.question_prompt);
        TextView answer = card.findViewById(R.id.question_answer);
        TextView meta = card.findViewById(R.id.question_meta);
        ImageView image = card.findViewById(R.id.question_image);
        Button reveal = card.findViewById(R.id.reveal_button);
        Button review = card.findViewById(R.id.review_button);
        Button edit = card.findViewById(R.id.edit_button);
        Button mcqQuiz = card.findViewById(R.id.mcq_quiz_button);
        Button calendar = card.findViewById(R.id.calendar_button);
        Button delete = card.findViewById(R.id.delete_button);

        prompt.setText(question.prompt);
        answer.setText((question.isMcq() ? "شرح الإجابة:\n" : "الإجابة:\n") + question.answer);
        if (question.answer == null || question.answer.trim().isEmpty()) {
            reveal.setVisibility(View.GONE);
        } else if (question.isMcq()) {
            reveal.setText("أظهر الشرح");
        }
        mcqQuiz.setVisibility(question.isMcq() ? View.VISIBLE : View.GONE);
        mcqQuiz.setEnabled(question.hasValidMcq());
        String folderName = folderName(question.folderId);
        String folderText = folderName == null ? "" : "  ·  " + folderName;
        String typeText = question.isMcq() ? "اختيار من متعدد  ·  " : "";
        meta.setText(typeText + (Utils.isDue(question.nextReviewDate)
                ? "مستحقة الآن  ·  " + Utils.reviewStageLabel(question.reviewStage) + folderText
                : "الموعد التالي: " + Utils.formatDate(question.nextReviewDate) + "  ·  "
                + Utils.reviewStageLabel(question.reviewStage) + folderText));

        if (question.imagePath != null && new File(question.imagePath).exists()) {
            Bitmap bitmap = BitmapFactory.decodeFile(question.imagePath);
            if (bitmap != null) {
                image.setImageBitmap(bitmap);
                image.setVisibility(View.VISIBLE);
            }
        }
        reveal.setOnClickListener(view -> {
            boolean showing = answer.getVisibility() == View.VISIBLE;
            answer.setVisibility(showing ? View.GONE : View.VISIBLE);
            reveal.setText(showing
                    ? (question.isMcq() ? "أظهر الشرح" : "أظهر الإجابة")
                    : (question.isMcq() ? "أخفِ الشرح" : "أخفِ الإجابة"));
        });
        review.setOnClickListener(view -> markReviewed(question));
        edit.setOnClickListener(view -> showQuestionDialog(question));
        mcqQuiz.setOnClickListener(view -> startSingleMcqQuiz(question));
        calendar.setOnClickListener(view -> exportIcs(question));
        delete.setOnClickListener(view -> confirmDelete(question));
        parent.addView(card);
    }

    private void addMessage(LinearLayout parent, String message) {
        TextView empty = new TextView(this);
        empty.setText(message);
        empty.setTextColor(getColor(R.color.text_muted));
        empty.setTextSize(14);
        empty.setPadding(4, 12, 4, 12);
        parent.addView(empty);
    }

    private void showQuestionDialog(Question editing) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_question, null);
        EditText prompt = view.findViewById(R.id.prompt_input);
        EditText answer = view.findViewById(R.id.answer_input);
        EditText startDate = view.findViewById(R.id.start_date_input);
        Spinner questionType = view.findViewById(R.id.question_type);
        LinearLayout mcqFields = view.findViewById(R.id.mcq_fields);
        EditText[] optionInputs = {
                view.findViewById(R.id.option_1),
                view.findViewById(R.id.option_2),
                view.findViewById(R.id.option_3),
                view.findViewById(R.id.option_4)
        };
        Spinner correctOption = view.findViewById(R.id.correct_option);
        Spinner questionFolder = view.findViewById(R.id.question_folder);
        Button imageButton = view.findViewById(R.id.image_button);
        ImageView imagePreview = view.findViewById(R.id.image_preview);
        Button removeImage = view.findViewById(R.id.remove_image_button);

        ArrayList<String> typeLabels = new ArrayList<>();
        typeLabels.add("سؤال مفتوح");
        typeLabels.add("اختيار من متعدد");
        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, typeLabels
        );
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        questionType.setAdapter(typeAdapter);

        ArrayList<String> correctLabels = new ArrayList<>();
        correctLabels.add("الخيار الأول هو الصحيح");
        correctLabels.add("الخيار الثاني هو الصحيح");
        correctLabels.add("الخيار الثالث هو الصحيح");
        correctLabels.add("الخيار الرابع هو الصحيح");
        ArrayAdapter<String> correctAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, correctLabels
        );
        correctAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        correctOption.setAdapter(correctAdapter);

        ArrayList<String> folderLabels = new ArrayList<>();
        folderLabels.add("بدون مجلد");
        for (Folder folder : orderedFolders()) folderLabels.add(folderDisplayLabel(folder));
        ArrayAdapter<String> folderAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, folderLabels);
        folderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        questionFolder.setAdapter(folderAdapter);

        if (editing != null) {
            prompt.setText(editing.prompt);
            answer.setText(editing.answer);
            startDate.setText(editing.startDate);
            questionType.setSelection(editing.isMcq() ? 1 : 0);
            if (editing.isMcq() && editing.options != null) {
                for (int index = 0; index < Math.min(optionInputs.length, editing.options.size()); index++) {
                    optionInputs[index].setText(editing.options.get(index));
                }
                if (editing.correctOptionIndex >= 0 && editing.correctOptionIndex < optionInputs.length) {
                    correctOption.setSelection(editing.correctOptionIndex);
                }
            }
            questionFolder.setSelection(folderIndex(editing.folderId));
            activeImagePath = editing.imagePath;
            if (activeImagePath != null) showImagePreview(activeImagePath, imagePreview, removeImage);
        } else {
            startDate.setText(Utils.today());
            activeImagePath = null;
        }
        activePendingImageUri = null;
        activeImagePreview = imagePreview;
        activeRemoveImageButton = removeImage;

        questionType.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View item, int position, long id) {
                boolean isMcq = position == 1;
                mcqFields.setVisibility(isMcq ? View.VISIBLE : View.GONE);
                answer.setHint(isMcq ? "شرح الإجابة (اختياري)" : "الإجابة");
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });
        boolean startsAsMcq = questionType.getSelectedItemPosition() == 1;
        mcqFields.setVisibility(startsAsMcq ? View.VISIBLE : View.GONE);
        answer.setHint(startsAsMcq ? "شرح الإجابة (اختياري)" : "الإجابة");

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(editing == null ? "إضافة سؤال" : "تعديل السؤال")
                .setView(view)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حفظ", null)
                .create();
        activeQuestionDialog = dialog;

        imageButton.setOnClickListener(button -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            startActivityForResult(intent, REQUEST_IMAGE_FILE);
        });
        removeImage.setOnClickListener(button -> {
            activePendingImageUri = null;
            activeImagePath = null;
            imagePreview.setImageDrawable(null);
            imagePreview.setVisibility(View.GONE);
            removeImage.setVisibility(View.GONE);
        });

        dialog.setOnShowListener(ignored -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(button -> {
            String promptValue = prompt.getText().toString().trim();
            String answerValue = answer.getText().toString().trim();
            String dateValue = startDate.getText().toString().trim();
            boolean isMcq = questionType.getSelectedItemPosition() == 1;
            if (promptValue.isEmpty() || (!isMcq && answerValue.isEmpty())) {
                showToast(isMcq ? "اكتب نص السؤال أولًا" : "اكتب السؤال والإجابة أولًا");
                return;
            }
            if (!Utils.isValidDate(dateValue)) {
                showToast("اكتب التاريخ بهذا الشكل: YYYY-MM-DD");
                return;
            }

            ArrayList<String> options = new ArrayList<>();
            int correctIndex = -1;
            if (isMcq) {
                boolean foundEmptyOption = false;
                for (EditText optionInput : optionInputs) {
                    String option = optionInput.getText().toString().trim();
                    if (option.isEmpty()) {
                        foundEmptyOption = true;
                    } else {
                        if (foundEmptyOption) {
                            showToast("املأ الخيارات بالترتيب دون ترك فراغ");
                            return;
                        }
                        options.add(option);
                    }
                }
                if (options.size() < 2) {
                    showToast("أضف خيارين على الأقل");
                    return;
                }
                correctIndex = correctOption.getSelectedItemPosition();
                if (correctIndex < 0 || correctIndex >= options.size()) {
                    showToast("اختر إجابة صحيحة من الخيارات المكتوبة");
                    return;
                }
            }

            String imagePath = activeImagePath;
            if (activePendingImageUri != null) imagePath = copyImageToInternal(activePendingImageUri);
            String folderId = folderIdFromSpinner(questionFolder);
            if (editing == null) {
                questions.add(0, new Question(
                        Utils.newId(), promptValue, answerValue,
                        isMcq ? Question.TYPE_MCQ : Question.TYPE_OPEN,
                        options, correctIndex, dateValue, dateValue,
                        0, 0, null, folderId, imagePath
                ));
                showToast(isMcq ? "أضيف سؤال الاختيار من متعدد" : "أضيفت البطاقة إلى مكتبتك");
            } else {
                editing.prompt = promptValue;
                editing.answer = answerValue;
                editing.type = isMcq ? Question.TYPE_MCQ : Question.TYPE_OPEN;
                editing.options = options;
                editing.correctOptionIndex = correctIndex;
                editing.folderId = folderId;
                editing.imagePath = imagePath;
                if (!editing.startDate.equals(dateValue)) {
                    editing.startDate = dateValue;
                    editing.nextReviewDate = dateValue;
                    editing.reviewStage = 0;
                    editing.reviewCount = 0;
                    editing.lastReviewedAt = null;
                }
                showToast("تم حفظ التعديلات");
            }
            saveQuestionsAndSchedule();
            render();
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void showImportDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_import, null);
        EditText input = view.findViewById(R.id.import_input);
        Spinner importFolder = view.findViewById(R.id.import_folder);
        Button chooseFile = view.findViewById(R.id.choose_file_button);
        setupFolderSpinner(importFolder, null);
        activeImportInput = input;

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("استيراد مجموعة أسئلة")
                .setView(view)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("استيراد", null)
                .create();
        chooseFile.setOnClickListener(button -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            startActivityForResult(intent, REQUEST_IMPORT_FILE);
        });
        dialog.setOnShowListener(ignored -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(button -> {
            ArrayList<ImportParser.ImportedQuestion> imported = ImportParser.parse(input.getText().toString());
            if (imported.isEmpty()) {
                showToast("لم أجد أسئلة قابلة للاستيراد");
                return;
            }
            String folderId = folderIdFromSpinner(importFolder);
            for (ImportParser.ImportedQuestion item : imported) {
                questions.add(0, new Question(
                        Utils.newId(), item.prompt, item.answer, item.type,
                        item.options, item.correctOptionIndex, Utils.today(), Utils.today(),
                        0, 0, null, folderId, null
                ));
            }
            saveQuestionsAndSchedule();
            showToast("تم استيراد " + toArabicNumber(imported.size()) + " سؤالًا");
            render();
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void showFolderDialog() {
        showFolderDialog(null);
    }

    private void showFolderDialog(String parentFolderId) {
        EditText input = new EditText(this);
        input.setHint("اسم المجلد");
        input.setSingleLine(true);
        input.setPadding(20, 4, 20, 4);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(parentFolderId == null ? "إنشاء مجلد" : "إنشاء مجلد فرعي")
                .setView(input)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("إنشاء", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(button -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) {
                showToast("اكتب اسم المجلد");
                return;
            }
            Folder folder = new Folder(Utils.newId(), name, parentFolderId);
            folders.add(folder);
            storage.saveFolders(folders);
            selectedFolderId = folder.id;
            render();
            showToast(parentFolderId == null ? "تم إنشاء المجلد" : "تم إنشاء المجلد الفرعي");
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void markReviewed(Question question) {
        advanceReviewSchedule(question);
        showToast("أحسنت، انتقل السؤال إلى موعده التالي");
    }

    private void confirmDelete(Question question) {
        new AlertDialog.Builder(this)
                .setTitle("حذف السؤال؟")
                .setMessage("سيتم حذف السؤال من الهاتف ولا يمكن التراجع عن ذلك.")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف", (dialog, which) -> {
                    deleteQuestionImage(question);
                    questions.remove(question);
                    saveQuestionsAndSchedule();
                    render();
                    showToast("تم حذف السؤال");
                })
                .show();
    }

    private void confirmDeleteFolder(Folder folder) {
        Set<String> folderIds = new HashSet<>();
        collectFolderSubtree(folder.id, folderIds);
        int questionCount = 0;
        for (Question question : questions) {
            if (folderIds.contains(question.folderId)) questionCount++;
        }
        String message = "سيتم حذف «" + folder.name + "» وكل مجلداته الفرعية، مع "
                + toArabicNumber(questionCount) + " سؤالًا وصورها المرفقة. لا يمكن التراجع عن ذلك.";

        new AlertDialog.Builder(this)
                .setTitle("حذف المجلد ومحتوياته؟")
                .setMessage(message)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف الكل", (dialog, which) -> {
                    boolean selectionDeleted = folderIds.contains(selectedFolderId);
                    Iterator<Question> questionIterator = questions.iterator();
                    while (questionIterator.hasNext()) {
                        Question question = questionIterator.next();
                        if (folderIds.contains(question.folderId)) {
                            deleteQuestionImage(question);
                            questionIterator.remove();
                        }
                    }

                    Iterator<Folder> folderIterator = folders.iterator();
                    while (folderIterator.hasNext()) {
                        if (folderIds.contains(folderIterator.next().id)) folderIterator.remove();
                    }
                    storage.saveFolders(folders);
                    if (selectionDeleted) {
                        selectedFolderId = folder.parentId != null
                                && !folderIds.contains(folder.parentId)
                                && folderExists(folder.parentId)
                                ? folder.parentId
                                : null;
                    }
                    saveQuestionsAndSchedule();
                    render();
                    showToast("تم حذف المجلد ومحتوياته");
                })
                .show();
    }

    private void collectFolderSubtree(String folderId, Set<String> result) {
        if (folderId == null || !result.add(folderId)) return;
        for (Folder folder : folders) {
            if (folderId.equals(folder.parentId)) collectFolderSubtree(folder.id, result);
        }
    }

    private boolean folderExists(String folderId) {
        return findFolder(folderId) != null;
    }

    private Folder findFolder(String folderId) {
        if (folderId == null) return null;
        for (Folder folder : folders) {
            if (folder.id.equals(folderId)) return folder;
        }
        return null;
    }

    private void deleteQuestionImage(Question question) {
        if (question.imagePath == null || question.imagePath.isEmpty()) return;
        try {
            File imageDirectory = new File(getFilesDir(), "images").getCanonicalFile();
            File imageFile = new File(question.imagePath).getCanonicalFile();
            String allowedPrefix = imageDirectory.getPath() + File.separator;
            if (imageFile.getPath().startsWith(allowedPrefix) && imageFile.isFile()) {
                imageFile.delete();
            }
        } catch (IOException ignored) {
        }
    }

    private void exportJson() {
        JSONArray array = new JSONArray();
        for (Question question : questions) {
            try {
                array.put(question.toJson());
            } catch (Exception ignored) {
            }
        }
        pendingExport = array.toString(2);
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "ذاكرة-الأسئلة-" + Utils.today() + ".json");
        startActivityForResult(intent, REQUEST_EXPORT_FILE);
    }

    private void exportIcs(Question question) {
        String date = question.nextReviewDate.replace("-", "");
        String nextDate = Utils.addReviewInterval(question.nextReviewDate, question.reviewStage).replace("-", "");
        String stamp = Utils.nowIso().replace("-", "").replace(":", "").replace(".", "");
        String summary = escapeIcs("مراجعة: " + question.prompt);
        String description = escapeIcs(question.answer.replace("\n", " ").replace("\r", " "));
        pendingIcs = "BEGIN:VCALENDAR\r\n"
                + "VERSION:2.0\r\n"
                + "PRODID:-//ذاكرة//Question Review//AR\r\n"
                + "BEGIN:VEVENT\r\n"
                + "UID:" + question.id + "@thakera.app\r\n"
                + "DTSTAMP:" + stamp + "\r\n"
                + "DTSTART;VALUE=DATE:" + date + "\r\n"
                + "DTEND;VALUE=DATE:" + nextDate + "\r\n"
                + "SUMMARY:" + summary + "\r\n"
                + "DESCRIPTION:" + description + "\r\n"
                + "END:VEVENT\r\n"
                + "END:VCALENDAR\r\n";
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/calendar");
        intent.putExtra(Intent.EXTRA_TITLE, "مراجعة-" + question.nextReviewDate + ".ics");
        startActivityForResult(intent, REQUEST_EXPORT_ICS);
    }

    private String escapeIcs(String value) {
        return value.replace("\\", "\\\\")
                .replace(";", "\\;")
                .replace(",", "\\,")
                .replace("\n", "\\n");
    }

    private void setupFolderSpinner(Spinner spinner, String selectedId) {
        ArrayList<Folder> ordered = orderedFolders();
        ArrayList<String> labels = new ArrayList<>();
        labels.add("بدون مجلد");
        for (Folder folder : ordered) labels.add(folderDisplayLabel(folder));
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(folderIndex(selectedId));
    }

    private int folderIndex(String folderId) {
        if (folderId == null) return 0;
        ArrayList<Folder> ordered = orderedFolders();
        for (int index = 0; index < ordered.size(); index++) {
            if (folderId.equals(ordered.get(index).id)) return index + 1;
        }
        return 0;
    }

    private String folderIdFromSpinner(Spinner spinner) {
        int position = spinner.getSelectedItemPosition();
        ArrayList<Folder> ordered = orderedFolders();
        return position <= 0 || position > ordered.size() ? null : ordered.get(position - 1).id;
    }

    private String folderName(String folderId) {
        if (folderId == null) return null;
        ArrayList<String> names = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        Folder current = findFolder(folderId);
        while (current != null && visited.add(current.id)) {
            names.add(current.name);
            current = findFolder(current.parentId);
        }
        if (names.isEmpty()) return null;
        Collections.reverse(names);
        StringBuilder path = new StringBuilder();
        for (String name : names) {
            if (path.length() > 0) path.append(" / ");
            path.append(name);
        }
        return path.toString();
    }

    private void showImagePreview(String path, ImageView preview, Button removeButton) {
        Bitmap bitmap = BitmapFactory.decodeFile(path);
        if (bitmap == null) return;
        preview.setImageBitmap(bitmap);
        preview.setVisibility(View.VISIBLE);
        removeButton.setVisibility(View.VISIBLE);
    }

    private String copyImageToInternal(Uri uri) {
        try (InputStream stream = getContentResolver().openInputStream(uri)) {
            Bitmap source = BitmapFactory.decodeStream(stream);
            if (source == null) return null;
            int maxSize = 1280;
            float scale = Math.min(1f, maxSize / (float) Math.max(source.getWidth(), source.getHeight()));
            int width = Math.max(1, Math.round(source.getWidth() * scale));
            int height = Math.max(1, Math.round(source.getHeight() * scale));
            Bitmap scaled = Bitmap.createScaledBitmap(source, width, height, true);
            File directory = new File(getFilesDir(), "images");
            if (!directory.exists() && !directory.mkdirs()) return null;
            File output = new File(directory, Utils.newId() + ".jpg");
            try (FileOutputStream fileStream = new FileOutputStream(output)) {
                scaled.compress(Bitmap.CompressFormat.JPEG, 82, fileStream);
            }
            if (scaled != source) scaled.recycle();
            source.recycle();
            return output.getAbsolutePath();
        } catch (Exception exception) {
            showToast("تعذر حفظ الصورة");
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQUEST_IMPORT_FILE && activeImportInput != null) {
            activeImportInput.setText(readText(uri));
        } else if (requestCode == REQUEST_IMAGE_FILE && activeQuestionDialog != null) {
            activePendingImageUri = uri;
            try (InputStream stream = getContentResolver().openInputStream(uri)) {
                Bitmap bitmap = BitmapFactory.decodeStream(stream);
                if (bitmap != null && activeImagePreview != null) {
                    activeImagePreview.setImageBitmap(bitmap);
                    activeImagePreview.setVisibility(View.VISIBLE);
                    activeRemoveImageButton.setVisibility(View.VISIBLE);
                }
            } catch (Exception ignored) {
                showToast("تعذر معاينة الصورة");
            }
        } else if ((requestCode == REQUEST_EXPORT_FILE && pendingExport != null)
                || (requestCode == REQUEST_EXPORT_ICS && pendingIcs != null)) {
            String exportText = requestCode == REQUEST_EXPORT_ICS ? pendingIcs : pendingExport;
            try {
                android.os.ParcelFileDescriptor descriptor = getContentResolver().openFileDescriptor(uri, "w");
                if (descriptor == null) {
                    showToast("تعذر تصدير البيانات");
                    return;
                }
                try (FileOutputStream stream = new FileOutputStream(descriptor.getFileDescriptor())) {
                    stream.write(exportText.getBytes(StandardCharsets.UTF_8));
                } finally {
                    descriptor.close();
                }
                showToast(requestCode == REQUEST_EXPORT_ICS
                        ? "تم تصدير موعد المراجعة"
                        : "تم تصدير نسخة من بياناتك");
            } catch (Exception exception) {
                showToast("تعذر تصدير البيانات");
            }
        }
    }

    private String readText(Uri uri) {
        StringBuilder builder = new StringBuilder();
        try (InputStream stream = getContentResolver().openInputStream(uri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (builder.length() > 0) builder.append('\n');
                builder.append(line);
            }
        } catch (Exception exception) {
            showToast("تعذر قراءة الملف");
        }
        return builder.toString();
    }

    private void saveQuestionsAndSchedule() {
        storage.saveQuestions(questions);
        ReminderScheduler.rescheduleAll(this, questions);
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private String toArabicNumber(int value) {
        return String.valueOf(value)
                .replace('0', '٠').replace('1', '١').replace('2', '٢').replace('3', '٣')
                .replace('4', '٤').replace('5', '٥').replace('6', '٦').replace('7', '٧')
                .replace('8', '٨').replace('9', '٩');
    }
}