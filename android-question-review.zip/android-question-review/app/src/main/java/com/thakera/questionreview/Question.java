package com.thakera.questionreview;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Question {
    public static final String TYPE_OPEN = "open";
    public static final String TYPE_MCQ = "mcq";

    public String id;
    public String prompt;
    public String answer;
    public String type;
    public ArrayList<String> options;
    public int correctOptionIndex;
    public String startDate;
    public String nextReviewDate;
    public int reviewCount;
    public int reviewStage;
    public String lastReviewedAt;
    public String folderId;
    public String imagePath;

    public Question(String id, String prompt, String answer, String startDate,
                    String nextReviewDate, int reviewCount, int reviewStage,
                    String lastReviewedAt, String folderId, String imagePath) {
        this(id, prompt, answer, TYPE_OPEN, new ArrayList<>(), -1, startDate,
                nextReviewDate, reviewCount, reviewStage, lastReviewedAt, folderId, imagePath);
    }

    public Question(String id, String prompt, String answer, String type,
                    ArrayList<String> options, int correctOptionIndex, String startDate,
                    String nextReviewDate, int reviewCount, int reviewStage,
                    String lastReviewedAt, String folderId, String imagePath) {
        this.id = id;
        this.prompt = prompt;
        this.answer = answer;
        this.type = type;
        this.options = options;
        this.correctOptionIndex = correctOptionIndex;
        this.startDate = startDate;
        this.nextReviewDate = nextReviewDate;
        this.reviewCount = reviewCount;
        this.reviewStage = reviewStage;
        this.lastReviewedAt = lastReviewedAt;
        this.folderId = folderId;
        this.imagePath = imagePath;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject object = new JSONObject();
        object.put("id", id);
        object.put("prompt", prompt);
        object.put("answer", answer);
        object.put("type", type == null ? TYPE_OPEN : type);
        JSONArray optionArray = new JSONArray();
        if (options != null) {
            for (String option : options) optionArray.put(option);
        }
        object.put("options", optionArray);
        object.put("correctOptionIndex", correctOptionIndex);
        object.put("startDate", startDate);
        object.put("nextReviewDate", nextReviewDate);
        object.put("reviewCount", reviewCount);
        object.put("reviewStage", reviewStage);
        object.put("lastReviewedAt", lastReviewedAt == null ? JSONObject.NULL : lastReviewedAt);
        object.put("folderId", folderId == null ? JSONObject.NULL : folderId);
        object.put("imagePath", imagePath == null ? JSONObject.NULL : imagePath);
        return object;
    }

    public boolean isMcq() {
        return TYPE_MCQ.equals(type);
    }

    public boolean hasValidMcq() {
        if (!isMcq() || options == null || options.size() < 2 || options.size() > 4
                || correctOptionIndex < 0 || correctOptionIndex >= options.size()) {
            return false;
        }
        for (String option : options) {
            if (option == null || option.trim().isEmpty()) return false;
        }
        return true;
    }

    public static Question fromJson(JSONObject object) {
        String start = object.optString("startDate", Utils.today());
        String type = TYPE_MCQ.equals(object.optString("type", TYPE_OPEN)) ? TYPE_MCQ : TYPE_OPEN;
        ArrayList<String> options = new ArrayList<>();
        JSONArray optionArray = object.optJSONArray("options");
        if (optionArray != null) {
            for (int index = 0; index < optionArray.length(); index++) {
                options.add(optionArray.optString(index, ""));
            }
        }
        return new Question(
                object.optString("id", Utils.newId()),
                object.optString("prompt", ""),
                object.optString("answer", ""),
                type,
                options,
                object.optInt("correctOptionIndex", -1),
                start,
                object.optString("nextReviewDate", start),
                object.optInt("reviewCount", 0),
                Math.max(0, Math.min(3, object.optInt("reviewStage", 0))),
                nullableString(object, "lastReviewedAt"),
                nullableString(object, "folderId"),
                nullableString(object, "imagePath")
        );
    }

    private static String nullableString(JSONObject object, String key) {
        String value = object.optString(key, "");
        return value.isEmpty() ? null : value;
    }
}