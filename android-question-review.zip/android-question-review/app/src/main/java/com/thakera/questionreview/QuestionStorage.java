package com.thakera.questionreview;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class QuestionStorage {
    private static final String PREFS_NAME = "question_review_storage";
    private static final String QUESTIONS_KEY = "questions";
    private static final String FOLDERS_KEY = "folders";
    private final SharedPreferences preferences;

    public QuestionStorage(Context context) {
        preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public ArrayList<Question> loadQuestions() {
        ArrayList<Question> result = new ArrayList<>();
        String raw = preferences.getString(QUESTIONS_KEY, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int index = 0; index < array.length(); index++) {
                result.add(Question.fromJson(array.getJSONObject(index)));
            }
        } catch (JSONException ignored) {
            // A damaged local value should not prevent the app from opening.
        }
        return result;
    }

    public ArrayList<Folder> loadFolders() {
        ArrayList<Folder> result = new ArrayList<>();
        String raw = preferences.getString(FOLDERS_KEY, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int index = 0; index < array.length(); index++) {
                result.add(Folder.fromJson(array.getJSONObject(index)));
            }
        } catch (JSONException ignored) {
        }
        return result;
    }

    public void saveQuestions(ArrayList<Question> questions) {
        JSONArray array = new JSONArray();
        for (Question question : questions) {
            try {
                array.put(question.toJson());
            } catch (JSONException ignored) {
            }
        }
        preferences.edit().putString(QUESTIONS_KEY, array.toString()).apply();
    }

    public void saveFolders(ArrayList<Folder> folders) {
        JSONArray array = new JSONArray();
        for (Folder folder : folders) {
            try {
                array.put(folder.toJson());
            } catch (JSONException ignored) {
            }
        }
        preferences.edit().putString(FOLDERS_KEY, array.toString()).apply();
    }
}