package com.thakera.questionreview;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import java.util.ArrayList;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "review_reminders";

    @Override
    public void onReceive(Context context, Intent intent) {
        String reminderDate = intent.getStringExtra(ReminderScheduler.extraDate());
        if (reminderDate == null || ReminderScheduler.wasNotified(context, reminderDate)) return;

        ArrayList<Question> questions = new QuestionStorage(context).loadQuestions();
        ArrayList<Question> dueQuestions = new ArrayList<>();
        for (Question question : questions) {
            if (question.nextReviewDate != null && question.nextReviewDate.compareTo(reminderDate) <= 0) {
                dueQuestions.add(question);
            }
        }
        if (dueQuestions.isEmpty()) {
            ReminderScheduler.rescheduleAll(context, questions);
            return;
        }

        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel(manager);
        if (!canNotify(context, manager)) {
            ReminderScheduler.markNotified(context, reminderDate);
            ReminderScheduler.rescheduleAll(context, questions);
            return;
        }

        Intent openApp = new Intent(context, MainActivity.class);
        openApp.putExtra("open_calendar_date", reminderDate);
        openApp.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                reminderDate.hashCode(),
                openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String content = dueQuestions.size() == 1
                ? dueQuestions.get(0).prompt
                : "لديك " + dueQuestions.size() + " أسئلة للمراجعة";
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context).setPriority(Notification.PRIORITY_DEFAULT);
        Notification notification = builder
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("حان وقت مراجعة أسئلتك")
                .setContentText(content)
                .setStyle(new Notification.BigTextStyle().bigText(content))
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setCategory(Notification.CATEGORY_REMINDER)
                .build();

        manager.notify(reminderDate.hashCode(), notification);
        ReminderScheduler.markNotified(context, reminderDate);
        ReminderScheduler.rescheduleAll(context, questions);
    }

    private void createChannel(NotificationManager manager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "تذكيرات المراجعة",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("إشعار محلي عند حلول موعد مراجعة الأسئلة");
            manager.createNotificationChannel(channel);
        }
    }

    private boolean canNotify(Context context, NotificationManager manager) {
        if (Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 24 && !manager.areNotificationsEnabled()) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = manager.getNotificationChannel(CHANNEL_ID);
            return channel != null && channel.getImportance() != NotificationManager.IMPORTANCE_NONE;
        }
        return true;
    }
}
