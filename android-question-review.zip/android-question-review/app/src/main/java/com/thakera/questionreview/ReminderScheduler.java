package com.thakera.questionreview;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public final class ReminderScheduler {
    private static final String PREFS = "question_review_reminders";
    private static final String DATES_KEY = "scheduled_dates";
    private static final String EXTRA_DATE = "reminder_date";

    private ReminderScheduler() {
    }

    public static void rescheduleAll(Context context, ArrayList<Question> questions) {
        rescheduleAll(context, questions, false);
    }

    public static void rescheduleAll(Context context, ArrayList<Question> questions, boolean force) {
        Context appContext = context.getApplicationContext();
        Set<String> desiredDates = new TreeSet<>();
        String today = Utils.today();
        String todayNotifiedKey = notifiedKey(today);
        boolean notifiedToday = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(todayNotifiedKey, false);

        for (Question question : questions) {
            if (question.nextReviewDate == null) continue;
            String scheduledDate = question.nextReviewDate;
            if (scheduledDate.compareTo(today) < 0) scheduledDate = today;
            if (scheduledDate.equals(today) && notifiedToday) {
                scheduledDate = Utils.addDays(today, 1);
            }
            desiredDates.add(scheduledDate);
        }

        android.content.SharedPreferences preferences =
                appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> previousDates = readDates(preferences.getString(DATES_KEY, ""));
        if (!force && previousDates.equals(desiredDates)) return;

        AlarmManager alarmManager = (AlarmManager) appContext.getSystemService(Context.ALARM_SERVICE);
        for (String oldDate : previousDates) {
            PendingIntent oldAlarm = pendingIntent(appContext, oldDate, PendingIntent.FLAG_NO_CREATE);
            if (oldAlarm != null) {
                alarmManager.cancel(oldAlarm);
                oldAlarm.cancel();
            }
        }

        for (String date : desiredDates) {
            PendingIntent alarm = pendingIntent(appContext, date, PendingIntent.FLAG_UPDATE_CURRENT);
            if (alarm != null) {
                alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerAt(date),
                        alarm
                );
            }
        }
        StringBuilder serializedDates = new StringBuilder();
        for (String date : desiredDates) {
            if (serializedDates.length() > 0) serializedDates.append('\n');
            serializedDates.append(date);
        }
        preferences.edit().putString(DATES_KEY, serializedDates.toString()).apply();
    }

    static boolean wasNotified(Context context, String date) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(notifiedKey(date), false);
    }

    static void markNotified(Context context, String date) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(notifiedKey(date), true).apply();
    }

    static String extraDate() {
        return EXTRA_DATE;
    }

    private static String notifiedKey(String date) {
        return "notified_" + date;
    }

    private static Set<String> readDates(String raw) {
        Set<String> result = new HashSet<>();
        if (raw == null || raw.isEmpty()) return result;
        for (String date : raw.split("\n")) {
            if (!date.isEmpty()) result.add(date);
        }
        return result;
    }

    private static PendingIntent pendingIntent(Context context, String date, int flag) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.setAction("com.thakera.questionreview.REMINDER." + date);
        intent.putExtra(EXTRA_DATE, date);
        int flags = PendingIntent.FLAG_IMMUTABLE;
        if (flag == PendingIntent.FLAG_UPDATE_CURRENT) {
            flags |= PendingIntent.FLAG_UPDATE_CURRENT;
        } else {
            flags |= PendingIntent.FLAG_NO_CREATE;
        }
        return PendingIntent.getBroadcast(context, date.hashCode(), intent, flags);
    }

    private static long triggerAt(String date) {
        Calendar trigger = Calendar.getInstance();
        String[] parts = date.split("-");
        trigger.set(Calendar.YEAR, Integer.parseInt(parts[0]));
        trigger.set(Calendar.MONTH, Integer.parseInt(parts[1]) - 1);
        trigger.set(Calendar.DAY_OF_MONTH, Integer.parseInt(parts[2]));
        trigger.set(Calendar.HOUR_OF_DAY, 9);
        trigger.set(Calendar.MINUTE, 0);
        trigger.set(Calendar.SECOND, 0);
        trigger.set(Calendar.MILLISECOND, 0);
        long triggerAt = trigger.getTimeInMillis();
        if (triggerAt <= System.currentTimeMillis()) {
            triggerAt = System.currentTimeMillis() + 60_000L;
        }
        return triggerAt;
    }
}
