package com.thakera.questionreview;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public final class Utils {
    private static final String DATE_PATTERN = "yyyy-MM-dd";

    private Utils() {
    }

    public static String newId() {
        return UUID.randomUUID().toString();
    }

    public static String today() {
        return dateFormat().format(new Date());
    }

    public static String todayDate(Calendar calendar) {
        return dateFormat().format(calendar.getTime());
    }

    public static String nowIso() {
        return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).format(new Date());
    }

    public static String addDays(String value, int days) {
        Calendar calendar = Calendar.getInstance();
        try {
            calendar.setTime(dateFormat().parse(value));
        } catch (ParseException ignored) {
            calendar.setTime(new Date());
        }
        calendar.add(Calendar.DAY_OF_YEAR, days);
        return dateFormat().format(calendar.getTime());
    }

    public static String addReviewInterval(String value, int stage) {
        if (stage == 0) return addDays(value, 3);
        if (stage == 1) return addDays(value, 7);
        Calendar calendar = Calendar.getInstance();
        try {
            calendar.setTime(dateFormat().parse(value));
        } catch (ParseException ignored) {
            calendar.setTime(new Date());
        }
        calendar.add(Calendar.MONTH, 1);
        return dateFormat().format(calendar.getTime());
    }

    public static boolean isDue(String nextReviewDate) {
        return nextReviewDate == null || nextReviewDate.compareTo(today()) <= 0;
    }

    public static boolean isValidDate(String value) {
        try {
            Date date = dateFormat().parse(value);
            return date != null && dateFormat().format(date).equals(value);
        } catch (ParseException exception) {
            return false;
        }
    }

    public static String formatDate(String value) {
        try {
            Date date = dateFormat().parse(value);
            return new SimpleDateFormat("d MMMM", new Locale("ar")).format(date);
        } catch (Exception ignored) {
            return value;
        }
    }

    public static String reviewStageLabel(int stage) {
        switch (Math.max(0, Math.min(3, stage))) {
            case 0:
                return "المراجعة الأولى";
            case 1:
                return "بعد ٣ أيام";
            case 2:
                return "بعد أسبوع";
            default:
                return "بعد شهر ثم شهريًا";
        }
    }

    private static SimpleDateFormat dateFormat() {
        SimpleDateFormat format = new SimpleDateFormat(DATE_PATTERN, Locale.US);
        format.setLenient(false);
        return format;
    }
}